from django.urls import path
from . import views


app_name = 'Shop'

urlpatterns = [
    path('',views.index, name='index'),
    path('cart/', views.cart, name='cart'),
    path('payment/',views.payment, name='payment'),
    path('register/',views.register, name='register'),
    path('shoegame/', views.shoegame, name='shoegame'),
    path('loginView/',views.loginView, name='loginView'),
    path('logoutView', views.logoutView, name='logoutView'),
]