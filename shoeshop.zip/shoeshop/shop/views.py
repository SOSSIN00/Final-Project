from django.shortcuts import render, redirect
from django.contrib import messages
from .forms import RegisterForm, LoginForm
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
# Create your views here.

def index(request):
    return render(request, 'shoegameback-end.html')

def cart(request):
    return render(request, 'Shoegame cart.html')

def payment(request):
    return render(request, 'payment.shoegame.html')

def shoegame(request):
    return render(request, 'shoegameback-end.html')

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)

        if form.is_valid():
            user = form.save()
            username = form.cleaned_data['username']
            password = form.cleaned_data['password1']
            user = authenticate(username = username,password = password)
            login(request, user)
            
            messages.success(request, 'You have registered successfully!')
            return redirect('Shop:loginView')
        else:
            messages.error(request, 'Registration unsuccessful! Please correct the errors below.')
            return render(request, 'register.html', {'form': form})
    else:
        form = UserCreationForm()

    return render(request, 'register.html', {'form': form})

def loginView(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)  
                messages.success(request, 'Login successful!!!!')
                return redirect('Shop:shoegame')  
            else:
                form = AuthenticationForm()
                messages.error(request, 'Invalid username or password', {'form':form})
    else:
        form = AuthenticationForm()

    return render(request, 'login.html', {'form': form})
            

def logoutView(request):
    logout(request)
    messages.success(request, "You have been logged out successfully!")
    return redirect('Shop:loginView') 